const hre = require("hardhat");

async function main() {
  const FirstSmartContract = await hre.ethers.getContractFactory("FirstSmartContract");
  const contract = await FirstSmartContract.deploy();
  await contract.waitForDeployment();
  console.log("FirstSmartContract deployed to:", await contract.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
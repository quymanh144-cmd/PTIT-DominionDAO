
import { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import {
  getInfo,
  getProposals,
  isWallectConnected,
} from './Blockchain.services';

import Header from './components/Header';
import Home from './views/Home';
import Proposal from './views/Proposal';

const App = () => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const initialize = async () => {
      try {
        await isWallectConnected();
        await getInfo();
        await getProposals();
      } catch (error) {
        console.error('Initialization error:', error);
      } finally {
        setLoaded(true);
      }
    };

    initialize();
  }, []);

  return (
    <div className="min-h-screen bg-white text-gray-900 dark:bg-[#212936] dark:text-gray-300">
      <Header />

      <main>
        {loaded ? (
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/proposal/:id" element={<Proposal />} />
            <Route
              path="*"
              element={<p className="p-8">Page not found.</p>}
            />
          </Routes>
        ) : (
          <p className="p-8">Loading DAO application...</p>
        )}
      </main>

      <ToastContainer
        position="top-center"
        autoClose={5000}
        closeOnClick
        pauseOnHover
      />
    </div>
  );
};

export default App;


import Web3 from 'web3';
import { setGlobalState, getGlobalState } from './store';
import abi from './abis/DominionDAO.json';

const { ethereum } = window;

if (ethereum) {
  window.web3 = new Web3(ethereum);
}

const connectWallet = async () => {
  try {
    if (!ethereum) {
      alert('Please install MetaMask');
      return;
    }

    const accounts = await ethereum.request({
      method: 'eth_requestAccounts',
    });

    setGlobalState(
      'connectedAccount',
      accounts[0].toLowerCase()
    );
  } catch (error) {
    reportError(error);
  }
};

const isWallectConnected = async () => {
  try {
    if (!ethereum) {
      alert('Please install MetaMask');
      return;
    }

    const accounts = await ethereum.request({
      method: 'eth_accounts',
    });

    if (accounts.length) {
      setGlobalState(
        'connectedAccount',
        accounts[0].toLowerCase()
      );
    }

    ethereum.on('chainChanged', () => {
      window.location.reload();
    });

    ethereum.on('accountsChanged', (newAccounts) => {
      setGlobalState(
        'connectedAccount',
        newAccounts.length
          ? newAccounts[0].toLowerCase()
          : ''
      );
    });
  } catch (error) {
    reportError(error);
  }
};

const getEtheriumContract = async () => {
  const connectedAccount = getGlobalState('connectedAccount');

  if (!connectedAccount) {
    throw new Error('Please connect your MetaMask wallet.');
  }

  if (!window.web3) {
    throw new Error('MetaMask provider is unavailable.');
  }

  const contractAddress =
    process.env.REACT_APP_CONTRACT_ADDRESS;

  if (!contractAddress) {
    throw new Error('Contract address is missing from .env.');
  }

  return new window.web3.eth.Contract(
    abi.abi,
    contractAddress
  );
};

const performContribute = async (amount) => {
  try {
    const contract = await getEtheriumContract();
    const account = getGlobalState('connectedAccount');

    const value = window.web3.utils.toWei(
      amount.toString(),
      'ether'
    );

    await contract.methods.contribute().send({
      from: account,
      value,
    });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

const getInfo = async () => {
  try {
    if (!ethereum) {
      alert('Please install MetaMask');
      return;
    }

    const contract = await getEtheriumContract();
    const account = getGlobalState('connectedAccount');

    const isStakeholder = await contract.methods
      .isStakeholder()
      .call({ from: account });

    const balance = await contract.methods
      .daoBalance()
      .call();

    const mybalance = await contract.methods
      .getBalance()
      .call({ from: account });

    setGlobalState(
      'balance',
      window.web3.utils.fromWei(balance, 'ether')
    );

    setGlobalState(
      'mybalance',
      window.web3.utils.fromWei(mybalance, 'ether')
    );

    setGlobalState('isStakeholder', isStakeholder);
  } catch (error) {
    reportError(error);
  }
};

const raiseProposal = async ({
  title,
  description,
  beneficiary,
  amount,
}) => {
  try {
    const contract = await getEtheriumContract();
    const account = getGlobalState('connectedAccount');

    const value = window.web3.utils.toWei(
      amount.toString(),
      'ether'
    );

    await contract.methods
      .createProposal(title, description, beneficiary, value)
      .send({ from: account });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

const getProposals = async () => {
  try {
    if (!ethereum) {
      alert('Please install MetaMask');
      return;
    }

    const contract = await getEtheriumContract();
    const proposals = await contract.methods
      .getProposals()
      .call();

    setGlobalState(
      'proposals',
      structuredProposals(proposals)
    );
  } catch (error) {
    reportError(error);
  }
};

const structuredProposals = (proposals) => {
  return proposals
    .map((proposal) => ({
      id: proposal.id,
      amount: window.web3.utils.fromWei(
        proposal.amount,
        'ether'
      ),
      title: proposal.title,
      description: proposal.description,
      paid: proposal.paid,
      passed: proposal.passed,
      proposer: proposal.proposer,
      upvotes: Number(proposal.upvotes),
      downvotes: Number(proposal.downvotes),
      beneficiary: proposal.beneficiary,
      executor: proposal.executor,
      duration: proposal.duration,
    }))
    .reverse();
};

const getProposal = async (id) => {
  try {
    const proposals = getGlobalState('proposals');

    return proposals.find(
      (proposal) => proposal.id == id
    );
  } catch (error) {
    reportError(error);
  }
};

const voteOnProposal = async (proposalId, supported) => {
  try {
    const contract = await getEtheriumContract();
    const account = getGlobalState('connectedAccount');

    await contract.methods
      .performVote(proposalId, supported)
      .send({ from: account });

    window.location.reload();
  } catch (error) {
    reportError(error);
  }
};

const listVoters = async (id) => {
  try {
    const contract = await getEtheriumContract();

    return await contract.methods
      .getVotesOf(id)
      .call();
  } catch (error) {
    reportError(error);
  }
};

  const payoutBeneficiary = async (id) => {
    try {
      const contract = await getEtheriumContract();
      const account = getGlobalState('connectedAccount');

      await contract.methods
        .payBeneficiary(id)
        .send({ from: account });

      window.location.reload();
    } catch (error) {
      reportError(error);
    }
  };

  const reportError = (error) => {
    console.error('Blockchain error:', error);
  };

  export {
    isWallectConnected,
    connectWallet,
    performContribute,
    getInfo,
    raiseProposal,
    getProposals,
    getProposal,
    voteOnProposal,
    listVoters,
    payoutBeneficiary,
  };

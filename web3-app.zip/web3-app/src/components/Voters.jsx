
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { listVoters } from '../Blockchain.services';

const Voters = () => {
  const { id } = useParams();
  const [voters, setVoters] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    const loadVoters = async () => {
      setLoading(true);

      try {
        const result = await listVoters(id);

        if (active) {
          setVoters(Array.isArray(result) ? result : []);
        }
      } catch (error) {
        console.error('Could not load voters:', error);
      } finally {
        if (active) setLoading(false);
      }
    };

    loadVoters();

    return () => {
      active = false;
    };
  }, [id]);

  return (
    <section className="p-8">
      <h2 className="text-2xl font-semibold mb-5">
        Proposal Voters
      </h2>

      {loading ? (
        <p>Loading voters...</p>
      ) : voters.length === 0 ? (
        <p className="text-gray-500">
          No voter information available.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-300 dark:border-gray-600">
                <th className="p-3">No.</th>
                <th className="p-3">Wallet address</th>
              </tr>
            </thead>

            <tbody>
              {voters.map((voter, index) => {
                const address =
                  typeof voter === 'string'
                    ? voter
                    : voter.voter || voter.account || '';

                return (
                  <tr
                    key={`${address}-${index}`}
                    className="border-b border-gray-200 dark:border-gray-700"
                  >
                    <td className="p-3">{index + 1}</td>
                    <td className="p-3 break-all">{address || 'Unknown'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
};

export default Voters;

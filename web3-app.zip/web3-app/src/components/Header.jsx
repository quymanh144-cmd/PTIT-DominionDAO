
import { useGlobalState } from '../store';
import { isWallectConnected } from '../Blockchain.services';

const Header = () => {
  const [connectedAccount] = useGlobalState('connectedAccount');

  const connectWallet = async () => {
    try {
      if (!window.ethereum) {
        alert('Please install MetaMask first.');
        return;
      }

      // Yêu cầu MetaMask cấp quyền kết nối tài khoản
      await window.ethereum.request({
        method: 'eth_requestAccounts',
      });

      // Dùng hàm hiện có của dự án để khởi tạo kết nối blockchain
      await isWallectConnected();
    } catch (error) {
      console.error('Wallet connection failed:', error);
      alert('Unable to connect wallet. Please try again.');
    }
  };

  const shortAddress = (address) =>
    address ? `${address.slice(0, 6)}...${address.slice(-4)}` : '';

  return (
    <header className="sticky top-0 z-50 border-b border-slate-700/60 bg-slate-950/95 text-white backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-4">
        <a href="/" className="flex items-center gap-3 no-underline">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-lg font-black shadow-lg shadow-blue-600/30">
            D
          </div>

          <div>
            <h1 className="text-lg font-bold tracking-tight">
              Dominion <span className="text-blue-400">DAO</span>
            </h1>
            <p className="text-xs text-slate-400">
              Decentralized governance
            </p>
          </div>
        </a>

        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-2 rounded-full border border-slate-700 bg-slate-900 px-3 py-2 text-xs sm:flex">
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
            <span className="text-slate-300">Sepolia Testnet</span>
          </div>

          <button
            type="button"
            onClick={connectWallet}
            className="rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-500"
          >
            {connectedAccount
              ? shortAddress(connectedAccount)
              : 'Connect Wallet'}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;

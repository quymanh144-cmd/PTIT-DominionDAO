
import { useState } from 'react';
import { useGlobalState, setGlobalState } from '../store';
import { toast } from 'react-toastify';
import { performContribute } from '../Blockchain.services';

const Banner = () => {
  const [isStakeholder] = useGlobalState('isStakeholder');
  const [proposals] = useGlobalState('proposals');
  const [balance] = useGlobalState('balance');
  const [mybalance] = useGlobalState('mybalance');
  const [amount, setAmount] = useState('0.03');
  const [submitting, setSubmitting] = useState(false);

  const opened = proposals.filter(
    (proposal) => Date.now() < Number(proposal.duration) * 1000
  ).length;

  const onPropose = () => {
    if (!isStakeholder) {
      toast.info('Contribute to the DAO to become a stakeholder first.');
      return;
    }

    setGlobalState('createModal', 'scale-100');
  };

  const onContribute = async () => {
    const value = Number(amount);

    if (!amount || !Number.isFinite(value) || value <= 0) {
      toast.error('Please enter a valid ETH amount.');
      return;
    }

    if (submitting) return;

    try {
      setSubmitting(true);

      const result = await performContribute(amount);

      if (!result) {
        toast.error('Please check the transaction status.');
        return;
      }

      toast.success('Contribution transaction completed!');
      setAmount('');
    } catch (error) {
      console.error('Contribution error:', error);
      toast.error(error?.message || 'Transaction failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const stats = [
    {
      label: 'Open Proposals',
      value: opened,
      note: 'Currently accepting votes',
      icon: '◈',
      color: 'bg-blue-100 text-blue-700',
    },
    {
      label: 'DAO Treasury',
      value: `${balance ?? 0} ETH`,
      note: 'Available DAO balance',
      icon: '◉',
      color: 'bg-violet-100 text-violet-700',
    },
    {
      label: 'Your Contributions',
      value: `${mybalance ?? 0} ETH`,
      note: isStakeholder ? 'DAO stakeholder' : 'Support the community',
      icon: '↗',
      color: 'bg-emerald-100 text-emerald-700',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-100 px-4 py-8 text-slate-900 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">

        {/* HERO BANNER */}
        <section
          className="relative overflow-hidden rounded-3xl px-6 py-9 shadow-xl sm:px-10 sm:py-12"
          style={{
            background:
              'linear-gradient(125deg, #0b1220 0%, #142b52 55%, #1d4ed8 100%)',
            color: '#ffffff',
          }}
        >
          <div
            className="pointer-events-none absolute -right-12 -top-20 h-64 w-64 rounded-full blur-3xl"
            style={{ backgroundColor: 'rgba(56, 189, 248, 0.22)' }}
          />

          <div
            className="pointer-events-none absolute -bottom-24 right-1/3 h-48 w-48 rounded-full blur-3xl"
            style={{ backgroundColor: 'rgba(129, 140, 248, 0.18)' }}
          />

          <div className="relative grid gap-8 md:grid-cols-[1.4fr_0.6fr] md:items-center">
            <div>
              <div
                className="mb-5 inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-bold tracking-wider"
                style={{
                  borderColor: 'rgba(255,255,255,0.25)',
                  backgroundColor: 'rgba(255,255,255,0.12)',
                  color: '#bae6fd',
                }}
              >
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                DECENTRALIZED GOVERNANCE
              </div>

              <h2 className="max-w-2xl text-3xl font-bold leading-tight tracking-tight sm:text-5xl">
                Your voice.
                <br />
                <span style={{ color: '#67e8f9' }}>
                  Your community.
                </span>
              </h2>

              <p
                className="mt-4 max-w-xl text-sm leading-7 sm:text-base"
                style={{ color: '#e2e8f0' }}
              >
                Participate in community decisions, support the DAO treasury,
                and help shape the future through transparent on-chain
                governance.
              </p>

              <button
                type="button"
                onClick={() =>
                  document
                    .getElementById('contribute-section')
                    ?.scrollIntoView({
                      behavior: 'smooth',
                      block: 'center',
                    })
                }
                className="mt-7 rounded-xl px-5 py-3 text-sm font-bold transition hover:-translate-y-0.5"
                style={{
                  backgroundColor: '#ffffff',
                  color: '#172554',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.18)',
                }}
              >
                Explore contribution →
              </button>
            </div>

            {/* DAO OVERVIEW */}
            <div
              className="rounded-2xl border p-5 sm:p-6"
              style={{
                borderColor: 'rgba(255,255,255,0.22)',
                backgroundColor: 'rgba(7,18,40,0.62)',
                backdropFilter: 'blur(12px)',
              }}
            >
              <p className="text-sm font-medium" style={{ color: '#bfdbfe' }}>
                DAO at a glance
              </p>

              <p className="mt-3 text-5xl font-bold" style={{ color: '#ffffff' }}>
                {opened}
              </p>

              <p className="mt-2 text-sm" style={{ color: '#e2e8f0' }}>
                Open proposals
              </p>

              <div
                className="my-5 border-t"
                style={{ borderColor: 'rgba(255,255,255,0.2)' }}
              />

              <div className="flex items-center justify-between gap-3">
                <span className="text-sm" style={{ color: '#e2e8f0' }}>
                  Network
                </span>

                <span
                  className="rounded-full px-3 py-1.5 text-xs font-bold"
                  style={{
                    backgroundColor: 'rgba(52,211,153,0.18)',
                    color: '#a7f3d0',
                    border: '1px solid rgba(52,211,153,0.3)',
                  }}
                >
                  Sepolia Testnet
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* STATISTICS */}
        <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-slate-500">
                    {stat.label}
                  </p>

                  <p className="mt-3 break-words text-2xl font-bold tracking-tight text-slate-900">
                    {stat.value}
                  </p>
                </div>

                <div
                  className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-2xl ${stat.color}`}
                >
                  {stat.icon}
                </div>
              </div>

              <p className="mt-3 text-xs font-medium text-slate-500">
                {stat.note}
              </p>
            </div>
          ))}
        </section>

        {/* CONTRIBUTION AND GOVERNANCE */}
        <section
          id="contribute-section"
          className="mt-6 grid gap-6 lg:grid-cols-[1fr_0.85fr]"
        >
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-blue-100 text-2xl font-bold text-blue-700">
                ↗
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900">
                  Support the DAO
                </h3>

                <p className="mt-2 text-sm leading-6 text-slate-600">
                  Contribute test ETH to become a stakeholder and participate
                  in governance.
                </p>
              </div>
            </div>

            <label
              htmlFor="contribution-amount"
              className="mt-7 block text-sm font-bold text-slate-700"
            >
              Contribution amount
            </label>

            <div className="mt-2 flex items-center rounded-xl border border-slate-300 bg-slate-50 px-4 transition focus-within:border-blue-500 focus-within:ring-4 focus-within:ring-blue-500/10">
              <input
                id="contribution-amount"
                type="number"
                min="0.001"
                step="0.001"
                inputMode="decimal"
                placeholder="0.03"
                value={amount}
                onChange={(event) => setAmount(event.target.value)}
                className="w-full border-0 bg-transparent py-4 text-xl font-bold text-slate-900 outline-none focus:ring-0"
              />

              <span className="ml-3 rounded-lg bg-white px-3 py-2 text-sm font-bold text-blue-700 shadow-sm">
                ETH
              </span>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {['0.01', '0.03', '0.05'].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setAmount(value)}
                  className={`rounded-lg border px-3 py-2 text-xs font-bold transition ${
                    amount === value
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-blue-400 hover:bg-blue-50'
                  }`}
                >
                  {value} ETH
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={onContribute}
              disabled={submitting}
              className="mt-5 w-full rounded-xl bg-blue-600 px-5 py-3.5 text-sm font-bold text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {submitting ? 'Waiting for transaction...' : 'Contribute to DAO'}
            </button>

            <p className="mt-3 text-center text-xs leading-5 text-slate-500">
              MetaMask will ask you to review and confirm the transaction.
              Sepolia ETH is for testing only.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-violet-100 text-2xl font-bold text-violet-700">
              ◈
            </div>

            <h3 className="mt-4 text-xl font-bold text-slate-900">
              Participate in governance
            </h3>

            <p className="mt-2 text-sm leading-7 text-slate-600">
              Stakeholders can create proposals and take part in decisions
              according to the DAO smart contract rules.
            </p>

            <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-4">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Your membership
              </p>

              <p className="mt-2 text-base font-bold text-slate-900">
                {isStakeholder
                  ? 'Stakeholder active'
                  : 'Not a stakeholder yet'}
              </p>

              <p className="mt-2 text-sm leading-6 text-slate-600">
                {isStakeholder
                  ? 'You can create a proposal.'
                  : 'Contribute first to unlock proposal creation, if permitted by the contract.'}
              </p>
            </div>

            {isStakeholder && (
              <button
                type="button"
                onClick={onPropose}
                className="mt-5 w-full rounded-xl border border-blue-200 bg-blue-50 px-5 py-3.5 text-sm font-bold text-blue-700 transition hover:bg-blue-100"
              >
                + Create a proposal
              </button>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Banner;

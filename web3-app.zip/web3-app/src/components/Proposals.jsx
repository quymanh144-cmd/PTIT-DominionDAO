import { Link } from 'react-router-dom';
import { useGlobalState, daysRemaining } from '../store';
import { payoutBeneficiary } from '../Blockchain.services';
import { toast } from 'react-toastify';

const Proposals = () => {
  const [proposals] = useGlobalState('proposals');

  const handlePayout = async (id) => {
    const confirmed = window.confirm(
      'Are you sure you want to execute this payout?'
    );

    if (!confirmed) return;

    await payoutBeneficiary(id);
    toast.info('Payout transaction submitted. Check MetaMask and the blockchain.');
  };

  if (!proposals.length) {
    return (
      <div className="p-8">
        <h2 className="text-2xl font-semibold mb-4 text-slate-100">
          DAO Proposals
        </h2>
        <p className="text-slate-400">
          No proposals yet. Connect your wallet and create the first one.
        </p>
      </div>
    );
  }

  return (
    <section className="p-8">
      <h2 className="text-2xl font-semibold mb-6 text-slate-100">
        DAO Proposals
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {proposals.map((proposal) => {
          const expired =
            Date.now() >= Number(proposal.duration) * 1000;

          const passedVotes =
            Number(proposal.upvotes) > Number(proposal.downvotes);

          const statusText = proposal.paid
            ? 'Paid'
            : expired && passedVotes
              ? 'Passed'
              : expired
                ? 'Expired'
                : 'Voting';

          const statusColor = proposal.paid
            ? 'text-green-300'
            : expired && passedVotes
              ? 'text-blue-300'
              : expired
                ? 'text-amber-300'
                : 'text-sky-300';

          return (
            <div
              key={String(proposal.id)}
              className="p-5 rounded-xl border border-slate-600
                         bg-slate-900 text-slate-100 shadow-md"
            >
              <h3 className="text-xl font-semibold mb-3 text-white break-words">
                {proposal.title}
              </h3>

              <p className="text-sm text-slate-300 mb-4 break-words">
                {proposal.description}
              </p>

              <p className="mb-2 text-slate-300">
                Amount:{' '}
                <strong className="text-white">{proposal.amount} ETH</strong>
              </p>

              <p className="mb-2 break-all text-slate-300">
                Beneficiary:{' '}
                <span className="text-white">{proposal.beneficiary}</span>
              </p>

              <p className="mb-2 text-slate-300">
                Accept votes:{' '}
                <strong className="text-blue-300">{proposal.upvotes}</strong>
              </p>

              <p className="mb-2 text-slate-300">
                Reject votes:{' '}
                <strong className="text-red-300">{proposal.downvotes}</strong>
              </p>

              <p className="mb-4 text-slate-300">
                Status:{' '}
                <strong className={statusColor}>{statusText}</strong>
              </p>

              <p className="text-sm text-slate-300 mb-4">
                {expired
                  ? 'Voting period has ended.'
                  : `Time remaining: ${daysRemaining(proposal.duration)}`}
              </p>

              <div className="flex flex-wrap gap-3">
                <Link
                  to={`/proposal/${proposal.id}`}
                  className="px-4 py-2 bg-blue-600 text-white
                             rounded-lg hover:bg-blue-700"
                >
                  View details / Vote
                </Link>

                {expired &&
                  !proposal.paid &&
                  passedVotes && (
                    <button
                      type="button"
                      onClick={() => handlePayout(proposal.id)}
                      className="px-4 py-2 bg-green-600 text-white
                                 rounded-lg hover:bg-green-700"
                    >
                      Execute payout
                    </button>
                  )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default Proposals;

import { useParams } from 'react-router-dom';
import {
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { toast } from 'react-toastify';
import { voteOnProposal } from '../Blockchain.services';
import { useGlobalState, daysRemaining } from '../store';

const ProposalDetails = () => {
  const { id } = useParams();
  const [proposals] = useGlobalState('proposals');
  const [isStakeholder] = useGlobalState('isStakeholder');

  // Lấy proposal trực tiếp từ danh sách trong global state.
  // Khi danh sách tải xong, trang tự cập nhật, không cần bấm lại.
  const proposal =
    proposals.find((p) => String(p.id) === String(id)) || null;

  const handleVote = async (choice) => {
    if (!proposal) return;

    if (Date.now() >= Number(proposal.duration) * 1000) {
      toast.warning('Proposal voting period has ended.');
      return;
    }

    try {
      await voteOnProposal(id, choice);
      toast.info('Vote transaction requested. Check MetaMask.');
    } catch (error) {
      console.error('Voting failed:', error);
      toast.error(error.message || 'Voting failed.');
    }
  };

  if (!proposal) {
    return (
      <section className="min-h-screen p-8 text-slate-100">
        <p className="font-semibold">
          Proposal not found or still loading.
        </p>
      </section>
    );
  }

  const data = [
    {
      name: 'Votes',
      Accept: Number(proposal.upvotes),
      Reject: Number(proposal.downvotes),
    },
  ];

  const expired = Date.now() >= Number(proposal.duration) * 1000;

  return (
    <section className="min-h-screen p-6 text-slate-100 sm:p-8">
      <div className="mx-auto max-w-4xl rounded-2xl border border-slate-600 bg-slate-900 p-6 shadow-md sm:p-8">
        <h2 className="mb-6 break-words text-3xl font-bold text-white">
          {proposal.title}
        </h2>

        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-slate-600 bg-slate-800 p-4">
            <p className="mb-1 text-sm font-semibold text-slate-300">
              Requested payout
            </p>
            <p className="text-xl font-bold text-white">
              {proposal.amount} ETH
            </p>
          </div>

          <div className="rounded-xl border border-slate-600 bg-slate-800 p-4">
            <p className="mb-1 text-sm font-semibold text-slate-300">
              Total votes
            </p>
            <p className="text-xl font-bold text-white">
              {Number(proposal.upvotes) + Number(proposal.downvotes)}
            </p>
          </div>
        </div>

        <div
          className={`mb-6 rounded-lg border p-4 font-semibold ${
            expired
              ? 'border-amber-700 bg-amber-950 text-amber-200'
              : 'border-blue-700 bg-blue-950 text-blue-200'
          }`}
        >
          {expired
            ? 'Voting period has ended.'
            : `Time remaining: ${daysRemaining(proposal.duration)}`}
        </div>

        <hr className="my-6 border-slate-600" />

        <div className="mb-8">
          <h3 className="mb-2 text-lg font-bold text-white">Description</h3>
          <p className="whitespace-pre-wrap break-words leading-7 text-slate-200">
            {proposal.description}
          </p>
        </div>

        <div className="mb-8 rounded-xl border border-slate-600 bg-white p-3 sm:p-5">
          <h3 className="mb-4 text-lg font-bold text-gray-950">
            Voting results
          </h3>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data}
                margin={{ top: 10, right: 12, left: 0, bottom: 8 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" />

                <XAxis
                  dataKey="name"
                  tick={{ fill: '#111827', fontSize: 13, fontWeight: 600 }}
                  axisLine={{ stroke: '#6b7280' }}
                  tickLine={{ stroke: '#6b7280' }}
                />

                <YAxis
                  allowDecimals={false}
                  tick={{ fill: '#111827', fontSize: 13 }}
                  axisLine={{ stroke: '#6b7280' }}
                  tickLine={{ stroke: '#6b7280' }}
                />

                <Tooltip
                  cursor={{ fill: '#e5e7eb', opacity: 0.5 }}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    color: '#111827',
                    border: '2px solid #6b7280',
                    borderRadius: '10px',
                    padding: '10px 14px',
                    fontWeight: 600,
                  }}
                  labelStyle={{
                    color: '#111827',
                    fontWeight: 700,
                    marginBottom: '5px',
                  }}
                  itemStyle={{ color: '#111827', fontWeight: 600 }}
                />

                <Legend
                  verticalAlign="bottom"
                  wrapperStyle={{
                    color: '#111827',
                    fontSize: '14px',
                    fontWeight: 700,
                    paddingTop: '12px',
                  }}
                />

                <Bar
                  dataKey="Accept"
                  name="Accept"
                  fill="#1d4ed8"
                  radius={[5, 5, 0, 0]}
                  maxBarSize={90}
                />

                <Bar
                  dataKey="Reject"
                  name="Reject"
                  fill="#b91c1c"
                  radius={[5, 5, 0, 0]}
                  maxBarSize={90}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {isStakeholder && !expired && !proposal.paid && (
          <div className="flex flex-wrap gap-4">
            <button
              type="button"
              onClick={() => handleVote(true)}
              className="rounded-lg bg-blue-700 px-7 py-3 font-bold text-white shadow-sm transition-colors hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-900"
            >
              Accept
            </button>

            <button
              type="button"
              onClick={() => handleVote(false)}
              className="rounded-lg bg-red-700 px-7 py-3 font-bold text-white shadow-sm transition-colors hover:bg-red-800 focus:outline-none focus:ring-4 focus:ring-red-900"
            >
              Reject
            </button>
          </div>
        )}

        {expired && (
          <p className="rounded-lg border border-slate-600 bg-slate-800 p-4 font-semibold text-slate-200">
            Voting is closed. The payout is available only if the proposal
            satisfies the smart contract requirements.
          </p>
        )}
      </div>
    </section>
  );
};

export default ProposalDetails;

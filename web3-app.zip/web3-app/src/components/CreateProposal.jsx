
import { useState } from 'react';
import { FaTimes } from 'react-icons/fa';
import { setGlobalState, useGlobalState } from '../store';
import { raiseProposal } from '../Blockchain.services';
import { toast } from 'react-toastify';

const CreateProposal = () => {
  const [createModal] = useGlobalState('createModal');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [beneficiary, setBeneficiary] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const resetForm = () => {
    setTitle('');
    setAmount('');
    setBeneficiary('');
    setDescription('');
  };

  const closeModal = () => {
    setGlobalState('createModal', 'scale-0');
    resetForm();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title.trim() || !description.trim() || !beneficiary.trim() ||
        !amount || Number(amount) <= 0) {
      toast.error('Please fill in all fields correctly.');
      return;
    }

    if (!/^0x[a-fA-F0-9]{40}$/.test(beneficiary.trim())) {
      toast.error('Beneficiary must be a valid Ethereum address.');
      return;
    }

    setSubmitting(true);

    try {
      await raiseProposal({
        title: title.trim(),
        description: description.trim(),
        beneficiary: beneficiary.trim(),
        amount,
      });

      toast.success('Proposal submitted.');
      closeModal();
    } catch (error) {
      toast.error(error.message || 'Could not create proposal.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className={`fixed inset-0 flex items-center justify-center
      bg-black bg-opacity-50 z-50 transition-transform duration-300
      ${createModal}`}
    >
      <div className="bg-white dark:bg-[#212936] shadow-xl rounded-xl
      w-11/12 md:w-2/5 max-h-[90vh] overflow-y-auto p-6">
        <form onSubmit={handleSubmit} className="flex flex-col">
          <div className="flex justify-between items-center">
            <p className="font-semibold">Create Proposal</p>
            <button
              type="button"
              onClick={closeModal}
              className="p-2"
              aria-label="Close"
            >
              <FaTimes />
            </button>
          </div>

          <input
            className="mt-5 p-3 border rounded-lg dark:bg-transparent"
            type="text"
            placeholder="Proposal title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />

          <input
            className="mt-4 p-3 border rounded-lg dark:bg-transparent"
            type="number"
            min="0.01"
            step="0.01"
            placeholder="Amount in ETH"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />

          <input
            className="mt-4 p-3 border rounded-lg dark:bg-transparent"
            type="text"
            placeholder="Beneficiary wallet address (0x...)"
            value={beneficiary}
            onChange={(e) => setBeneficiary(e.target.value)}
            required
          />

          <textarea
            className="mt-4 p-3 border rounded-lg dark:bg-transparent"
            placeholder="Proposal description"
            rows="4"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />

          <button
            type="submit"
            disabled={submitting}
            className="mt-5 rounded-lg px-6 py-3 bg-blue-600
            text-white font-medium hover:bg-blue-700
            disabled:opacity-50"
          >
            {submitting ? 'Submitting...' : 'Submit Proposal'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreateProposal;
